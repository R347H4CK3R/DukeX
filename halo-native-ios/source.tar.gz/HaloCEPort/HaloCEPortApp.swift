import SwiftUI

@main
struct HaloCEPortApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
