import SwiftUI
import UniformTypeIdentifiers

extension UTType {
    static let haloXboxMap = UTType(filenameExtension: "map") ?? .data
}

struct ContentView: View {
    @StateObject private var model = HaloPortModel()
    @State private var importer = false
    @State private var showingTags = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                ZStack(alignment: .topTrailing) {
                    HaloMetalView(mesh: model.mesh, wireframe: model.wireframe)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay {
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(.secondary.opacity(0.25), lineWidth: 1)
                        }

                    if model.isLoading {
                        ProgressView()
                            .padding(12)
                            .background(.ultraThinMaterial, in: Capsule())
                            .padding(10)
                    }
                }
                .frame(minHeight: 320)

                HStack {
                    Button("Choose .map") { importer = true }
                        .buttonStyle(.borderedProminent)

                    Toggle("Wireframe", isOn: $model.wireframe)
                        .toggleStyle(.button)

                    Button("Tags") { showingTags = true }
                        .buttonStyle(.bordered)
                        .disabled(model.map == nil)
                }

                ScrollView {
                    Text(model.status)
                        .font(.system(.caption, design: .monospaced))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .frame(maxHeight: 180)
            }
            .padding()
            .navigationTitle("Halo CE Native")
            .fileImporter(
                isPresented: $importer,
                allowedContentTypes: [.haloXboxMap, .data],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first { model.load(url) }
                case .failure(let error):
                    model.status = "File picker failed: \(error.localizedDescription)"
                }
            }
            .sheet(isPresented: $showingTags) {
                NavigationStack {
                    VStack {
                        TextField("Filter class, path, or ID", text: $model.filter)
                            .textFieldStyle(.roundedBorder)
                            .padding(.horizontal)

                        List(model.visibleTags) { tag in
                            VStack(alignment: .leading, spacing: 3) {
                                HStack {
                                    Text(tag.tagClass)
                                        .font(.system(.caption, design: .monospaced).bold())
                                    Spacer()
                                    Text(String(format: "0x%08X", tag.idValue))
                                        .font(.system(.caption2, design: .monospaced))
                                }
                                Text(tag.path.isEmpty ? "(unnamed)" : tag.path)
                                    .font(.caption)
                            }
                        }
                    }
                    .navigationTitle("Tag Browser")
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Done") { showingTags = false }
                        }
                    }
                }
            }
        }
    }
}
