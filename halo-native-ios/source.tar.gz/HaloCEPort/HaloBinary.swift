import Foundation

enum HaloBinary {
    static func u16(_ data: Data, _ offset: Int) -> UInt16 {
        data.withUnsafeBytes {
            UInt16(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: UInt16.self))
        }
    }

    static func i16(_ data: Data, _ offset: Int) -> Int16 {
        data.withUnsafeBytes {
            Int16(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: Int16.self))
        }
    }

    static func u32(_ data: Data, _ offset: Int) -> UInt32 {
        data.withUnsafeBytes {
            UInt32(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self))
        }
    }

    static func i32(_ data: Data, _ offset: Int) -> Int32 {
        data.withUnsafeBytes {
            Int32(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: Int32.self))
        }
    }

    static func f32(_ data: Data, _ offset: Int) -> Float {
        Float(bitPattern: u32(data, offset))
    }

    static func diskFourCC(_ data: Data, _ offset: Int) -> String {
        let bytes = Array(data[offset..<(offset + 4)]).reversed()
        return String(bytes: bytes, encoding: .ascii) ?? "????"
    }

    static func cString(_ data: Data, offset: Int, maxLength: Int = 512) -> String {
        guard offset >= 0, offset < data.count else { return "" }
        let limit = min(data.count, offset + maxLength)
        var end = offset
        while end < limit && data[end] != 0 { end += 1 }
        return String(decoding: data[offset..<end], as: UTF8.self)
    }
}
